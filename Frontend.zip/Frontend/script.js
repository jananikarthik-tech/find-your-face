// ============================================================
// CONFIG — ask your backend friend for the real base URL
// ============================================================
const API_BASE = "http://localhost:5000";
// Expected backend endpoints (confirm exact paths with your backend friend):
//   GET  /api/albums                     -> list of albums
//   POST /api/albums                     -> create a new album        (ADMIN ONLY — backend must check role)
//   POST /api/albums/<id>/upload         -> upload photos into an album (any logged-in user)
//   POST /api/find-my-photos             -> { album_id, selfie } -> { matched_photos: [...] }
//   Photos served from: API_BASE + "/photos/<album_id>/<filename>"
//
// ROLE: in production, role comes from login (see chat notes on Google
// Sign-In / username+password), not from the toggle buttons below.
// Replace currentRole's source with whatever your login flow returns.


// ============================================================
// DEMO DATA — remove once /api/albums is connected
// ============================================================
let albums = [
  { id: "tour_2026", name: "Tour 2026", icon: "🧭", color: "rgba(0,184,148,0.12)", photoCount: 312 },
  { id: "celebration_2026", name: "Celebration 2026", icon: "🎉", color: "rgba(233,30,140,0.1)", photoCount: 85 }
];

let currentRole = "admin"; // "admin" | "member" — DEMO toggle; replace with real login role
let selectedAlbum = null;  // album chosen in Albums or Upload tab
let currentAlbumPhotos = []; // File objects picked in the Upload detail view


// ============================================================
// Element references
// ============================================================
const albumListUser = document.getElementById('albumListUser');
const albumListUpload = document.getElementById('albumListUpload');
const tabCreate = document.getElementById('tabCreate');
const tabCapture = document.getElementById('tabCapture');
const captureLabel = document.getElementById('captureLabel');

const uploadList = document.getElementById('uploadList');
const uploadDetail = document.getElementById('uploadDetail');
const upIc = document.getElementById('upIc');
const upName = document.getElementById('upName');
const upMeta = document.getElementById('upMeta');
const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');
const thumbGrid = document.getElementById('thumbGrid');
const uploadStatus = document.getElementById('uploadStatus');
const uploadStatusText = document.getElementById('uploadStatusText');

const lens = document.getElementById('lens');
const openCamBtn = document.getElementById('openCamBtn');
const snapBtn = document.getElementById('snapBtn');
const retakeBtn = document.getElementById('retakeBtn');
const findBtn = document.getElementById('findBtn');
const statusEl = document.getElementById('status');
const statusText = document.getElementById('statusText');
const dot = document.getElementById('dot');
const canvas = document.getElementById('canvas');

const resultsSection = document.getElementById('resultsSection');
const resultLine = document.getElementById('resultLine');
const resultGrid = document.getElementById('resultGrid');

let stream = null, video = null, capturedDataUrl = null;


// ============================================================
// Tabs
// ============================================================
const screens = { tabAlbums: 'albumsScreen', tabCreate: 'createScreen', tabUpload: 'uploadScreen', tabCapture: 'captureScreen' };

function showTab(tabId) {
  const btn = document.getElementById(tabId);
  if (btn.classList.contains('hidden')) return;

  // Capture needs an album — if the user jumped here directly, default to the first one
  if (tabId === 'tabCapture' && !selectedAlbum && albums.length > 0) {
    selectedAlbum = albums[0];
    updateCaptureLabel();
  }

  Object.keys(screens).forEach(id => {
    document.getElementById(id).classList.toggle('active', id === tabId);
    document.getElementById(screens[id]).classList.toggle('active', id === tabId);
  });
}
Object.keys(screens).forEach(id => {
  document.getElementById(id).addEventListener('click', () => showTab(id));
});


// ============================================================
// Albums — render (both the Albums tab and the Upload tab use this)
// ============================================================
function renderAlbumCard(album, onClick) {
  const card = document.createElement('div');
  card.className = 'album-card';
  card.innerHTML = `
    <div class="album-ic" style="background:${album.color};">${album.icon}</div>
    <div class="album-info">
      <div class="name">${album.name}</div>
      <div class="meta">${album.photoCount} photos</div>
    </div>
    <div class="album-arrow">→</div>
  `;
  card.addEventListener('click', () => onClick(album));
  return card;
}

function loadAlbums() {
  // TODO: replace with: const res = await fetch(`${API_BASE}/api/albums`); albums = await res.json();
  albumListUser.innerHTML = '';
  albumListUpload.innerHTML = '';
  albums.forEach(album => {
    albumListUser.appendChild(renderAlbumCard(album, selectAlbumForCapture));
    albumListUpload.appendChild(renderAlbumCard(album, openUploadDetail));
  });
}

function updateCaptureLabel() {
  captureLabel.textContent = selectedAlbum.name + ' · tap to change album';
}

function selectAlbumForCapture(album) {
  selectedAlbum = album;
  updateCaptureLabel();
  showTab('tabCapture');
}


// ============================================================
// Create album (admin only — also enforce this check on the backend!)
// ============================================================
document.getElementById('createAlbumBtn').addEventListener('click', async () => {
  const nameInput = document.getElementById('newAlbumName');
  const name = nameInput.value.trim();
  if (!name) { alert('Enter an album name first.'); return; }

  // TODO: replace with real backend call:
  // const res = await fetch(`${API_BASE}/api/albums`, {
  //   method: 'POST', headers: {'Content-Type':'application/json'},
  //   body: JSON.stringify({ name })
  // });
  // const newAlbum = await res.json();

  const newAlbum = { id: name.toLowerCase().replace(/\s+/g, '_'), name, icon: '📷', color: 'rgba(0,184,148,0.12)', photoCount: 0 };
  albums.push(newAlbum);
  loadAlbums();
  nameInput.value = '';
  showTab('tabAlbums');
});


// ============================================================
// Upload detail — pick album, add/remove/download photos locally
// (replace with real upload-to-backend once that endpoint is ready)
// ============================================================
function openUploadDetail(album) {
  selectedAlbum = album;
  uploadList.style.display = 'none';
  uploadDetail.style.display = 'block';
  upIc.textContent = album.icon;
  upIc.style.background = album.color;
  upName.textContent = album.name;
  upMeta.textContent = album.photoCount + ' photos';
  currentAlbumPhotos = [];
  thumbGrid.innerHTML = '';
  uploadStatus.style.display = 'none';
}

document.getElementById('backToAlbumsBtn').addEventListener('click', () => {
  uploadList.style.display = 'block';
  uploadDetail.style.display = 'none';
});

dropZone.addEventListener('click', () => fileInput.click());

fileInput.addEventListener('change', async () => {
  currentAlbumPhotos = currentAlbumPhotos.concat(Array.from(fileInput.files));
  renderThumbs();
  uploadStatusText.textContent = 'Uploading ' + currentAlbumPhotos.length + ' photo(s)…';
  uploadStatus.style.display = 'flex';

  // TODO: replace with real backend upload:
  // const formData = new FormData();
  // currentAlbumPhotos.forEach(f => formData.append('photos', f));
  // await fetch(`${API_BASE}/api/albums/${selectedAlbum.id}/upload`, { method:'POST', body: formData });

  setTimeout(() => { uploadStatusText.textContent = 'Saved to this album.'; }, 700);
});

function renderThumbs() {
  thumbGrid.innerHTML = '';
  currentAlbumPhotos.forEach((file, index) => {
    const url = URL.createObjectURL(file);
    const div = document.createElement('div');
    div.className = 'thumb-item';
    div.innerHTML = `
      <img src="${url}">
      <button class="rm" type="button" data-index="${index}">✕</button>
      <a class="dl" href="${url}" download="${file.name}">⬇</a>
    `;
    div.querySelector('.rm').addEventListener('click', () => removePhoto(index));
    thumbGrid.appendChild(div);
  });
}

function removePhoto(index) {
  // TODO: if the photo was already uploaded to the backend, also call
  // a DELETE endpoint here so it's removed from the server, not just the UI.
  currentAlbumPhotos.splice(index, 1);
  renderThumbs();
  if (currentAlbumPhotos.length === 0) uploadStatus.style.display = 'none';
}


// ============================================================
// Role toggle — DEMO ONLY. Replace with real role from login.
// ============================================================
const roleAdminBtn = document.getElementById('roleAdminBtn');
const roleMemberBtn = document.getElementById('roleMemberBtn');
const roleBanner = document.getElementById('roleBanner');

function setRole(role) {
  currentRole = role;
  const isAdmin = role === 'admin';
  roleAdminBtn.classList.toggle('active', isAdmin);
  roleMemberBtn.classList.toggle('active', !isAdmin);
  tabCreate.classList.toggle('hidden', !isAdmin);

  roleBanner.classList.toggle('member', !isAdmin);
  roleBanner.innerHTML = isAdmin
    ? '⚙️ <span>Viewing as Admin — can create albums, upload, view, download</span>'
    : '👤 <span>Viewing as Member — can upload, view, download (no create)</span>';

  if (!isAdmin && document.getElementById('tabCreate').classList.contains('active')) {
    showTab('tabAlbums');
  }
}
roleAdminBtn.addEventListener('click', () => setRole('admin'));
roleMemberBtn.addEventListener('click', () => setRole('member'));


// ============================================================
// Camera capture
// ============================================================
function setStatus(text, mode) {
  statusText.textContent = text;
  statusEl.className = 'status' + (mode ? ' ' + mode : '');
}

async function openCamera() {
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
    video = document.createElement('video');
    video.autoplay = true; video.playsInline = true; video.srcObject = stream;
    lens.innerHTML = ''; lens.appendChild(video);
    openCamBtn.style.display = 'none';
    snapBtn.style.display = 'block';
    setStatus('Camera is on — center your face.');
  } catch (err) {
    setStatus('Camera access denied or unavailable.', 'error');
  }
}

function captureSelfie() {
  canvas.width = video.videoWidth; canvas.height = video.videoHeight;
  const ctx = canvas.getContext('2d');
  ctx.translate(canvas.width, 0); ctx.scale(-1, 1);
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  capturedDataUrl = canvas.toDataURL('image/jpeg', 0.9);

  stream.getTracks().forEach(t => t.stop());
  lens.innerHTML = `<img src="${capturedDataUrl}" style="transform:none;">`;
  snapBtn.style.display = 'none';
  retakeBtn.style.display = 'block';
  findBtn.disabled = false;
  setStatus('Selfie captured — tap "Find my photos".');
}

function retake() {
  capturedDataUrl = null;
  findBtn.disabled = true;
  retakeBtn.style.display = 'none';
  resultsSection.style.display = 'none';
  lens.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
      <circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.5-6 8-6s8 2 8 6"/></svg>`;
  openCamBtn.style.display = 'block';
  setStatus('Camera is off.');
}

openCamBtn.addEventListener('click', openCamera);
snapBtn.addEventListener('click', captureSelfie);
retakeBtn.addEventListener('click', retake);


// ============================================================
// Find my photos — sends album_id + selfie to backend
// ============================================================
async function findMyPhotos() {
  if (!capturedDataUrl || !selectedAlbum) return;

  findBtn.disabled = true;
  dot.classList.add('spin');
  setStatus('Searching ' + selectedAlbum.name + '…');
  resultsSection.style.display = 'none';

  try {
    const response = await fetch(`${API_BASE}/api/find-my-photos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ album_id: selectedAlbum.id, selfie: capturedDataUrl })
    });
    if (!response.ok) throw new Error('Server error: ' + response.status);

    const data = await response.json(); // { matched_photos: ["IMG_1.jpg", ...] }
    showResults(data.matched_photos || []);
  } catch (err) {
    setStatus('Could not reach the server. Is the backend running?', 'error');
  } finally {
    dot.classList.remove('spin');
    findBtn.disabled = false;
  }
}
findBtn.addEventListener('click', findMyPhotos);

function showResults(filenames) {
  resultGrid.innerHTML = '';
  if (filenames.length === 0) {
    setStatus('No matching photos found.', 'error');
    resultsSection.style.display = 'none';
    return;
  }
  filenames.forEach(filename => {
    const url = `${API_BASE}/photos/${selectedAlbum.id}/${filename}`;
    const div = document.createElement('div');
    div.className = 'thumb-item';
    div.innerHTML = `<img src="${url}"><a class="dl" href="${url}" download="${filename}">⬇</a>`;
    resultGrid.appendChild(div);
  });
  resultLine.innerHTML = `You appear in <b>${filenames.length}</b> photo(s).`;
  resultsSection.style.display = 'block';
  resultGrid.dataset.filenames = JSON.stringify(filenames);
  setStatus('Search complete.');
}

document.getElementById('downloadAllBtn').addEventListener('click', () => {
  resultGrid.querySelectorAll('a.dl').forEach(a => a.click());
});


// ============================================================
// Init
// ============================================================
loadAlbums();
setRole('admin');